1.make sure your linux server 9997 port is open.
2.put control.tar.gz on your linux。
tar -zxvf control.tar.gz
cd control
./control &
3.put control.apk on Android phone.
4.work it .

		——by yhliu

you can use unity to edit it.
